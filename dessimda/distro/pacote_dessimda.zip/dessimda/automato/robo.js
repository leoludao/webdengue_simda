const puppeteer = require('puppeteer');


async function dessimdar( vetorEntrada /* presume-se que o mesmo já esteja concatenado Lats seguidas de Longs*/  )
{
    const navegador = await puppeteer.launch( { headless: true } );
    const paginaWeb = await navegador.newPage();
    const uuurl = 'https://simda.sms.fortaleza.ce.gov.br/simda/dengue/mapa';    
    await paginaWeb.goto(uuurl);

    let eureka = [];

    let temp = ''
    for ( let i=0; i < vetorEntrada.length; i++)
    {
        if( vetorEntrada[i] != '-.0' )
        {
            let cripto = '';
            cripto += vetorEntrada[i];
            let mstrll = `Base64.decode('${cripto}')`;
            temp = await paginaWeb.evaluate(`${mstrll}`);
            eureka.push( parseFloat(temp) );
        }
        else
        {
            eureka.push( '-.0' );
        }
    }
    const vetorSaida = await eureka;
    await navegador.close();
    
    return vetorSaida
}


module.exports = { dessimdar }


