fs = require('fs')
robo = require('./automato/robo')
descript = require('./objeto/objetoSimda')
//lim = require('./geoLimites/limiteRegional.json')

const arqsL = __dirname + '/in'

var nomesArqs = fs.readdirSync( arqsL );

// Lando e carregando no Array 'conteúdo' Todos os conteúdos dos Arquivos da pasta de entrada 'in'
let conteudo = []
nomesArqs.forEach
( e =>
    {
        console.log(`\n\nLendo Arquivo ${e} ...`)
        conteudo.push ( fs.readFileSync( `${arqsL}/${e}`, 'utf-8') )
    }
)

// Criando Todos os Objetos Simda, um para cada Arquivo da pasta de entrada 'in'
let objSimda = []
for( let y = 0 ; y < conteudo.length; y++ )
{
        let e = nomesArqs[y]
        objSimda.push( new descript.ObjetoSimda( conteudo[y] ) )
}

// Descriptografando com o auxílio do RoboSimda
let vetorEntrada = []
for( let y = 0 ; y < conteudo.length; y++ )
{
    vetorEntrada = vetorEntrada.concat( objSimda[y].get_latLong_cript_concat() )
}
    
let saida = new Promise ((resolve, reject) =>
        {
            resolve( robo.dessimdar( vetorEntrada ) )
        }               )

saida   .then   ( vetorLL => 
        {   
            console.log(vetorLL.length)
            let vetorSaidaLat = []
            let vetorSaidaLong = []
            let l = 0
            for(let y = 0 ; y < conteudo.length ; y++ )
            {
                vetorSaidaLat = []
                vetorSaidaLong = []                
                let offset_atual = (objSimda[y]).get_num_pares()
                let fim_entrada_atual = l + offset_atual
                while( l < fim_entrada_atual )
                {
                    vetorSaidaLat.push(vetorLL[l])
                    vetorSaidaLong.push(vetorLL[l + offset_atual])
                    l++
                }
                objSimda[y].set_latLong_descript(vetorSaidaLat,vetorSaidaLong)
                l += offset_atual
            }

            for( let y = 0 ; y < conteudo.length; y++ )
            {
                objSimda[y].efetuar_podas( )
            }
        }       )

        .then   ( x2 =>
        {
            for( let y = 0 ; y < conteudo.length; y++ )
            {
                let e = nomesArqs[y]

                //Salvando Arquivo de Saída Descriptografado AINDA SEM PODAS ...
                let arqsTrechos = e.split('_ORIGINAL_')
                let extensao_csv = arqsTrechos[1].split('.txt')
                let arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_JSON_SEM_PODA_'
                arqsE += extensao_csv[0]
                arqsE += '.json'

                let sfd = JSON.stringify( objSimda[y].get_obj_JSON_descript_sem_podas() )

                fs.writeFile
                (   arqsE ,  sfd , 
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo JSON SEM PODA ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo JSON SEM PODA ${arqsE}.`)
                    }
                )

                //Salvando Arquivo de Saída JSON Descriptografado E AGORA SIM, PODADO...
                arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_JSON_'
                arqsE += extensao_csv[0]
                arqsE += '.json'

                let sfp = JSON.stringify( objSimda[y].get_obj_JSON_descript_podado() )

                fs.writeFile
                (   arqsE ,  sfp , 
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo JSON ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo JSON ${arqsE}.`)

                    }
                )
            
                //Salvando Arquivo JSON com Features OutLiers ...
                arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_JSON_OUTLIERS_'
                arqsE += extensao_csv[0]
                arqsE += '.json'

                let sfo = JSON.stringify( objSimda[y].get_obj_JSON_descript_outliers() )

                fs.writeFile
                (   arqsE ,  sfo , 
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo JSON dos OUTLIERS ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo JSON dos OUTLIERS ${arqsE}.`)

                    }
                )

                //Salvando Arquivo PONTOS com Features OutLiers ...
                arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_PONTOS_OUTLIERS_'
                arqsE += extensao_csv[0]
                arqsE += '.csv'

                let arqCSVOut = objSimda[y].get_str_CSV_pontos_outliers()

                fs.writeFile
                (   arqsE ,  arqCSVOut , 
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo PONTOS dos OUTLIERS ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo PONTOS dos OUTLIERS ${arqsE}.`)

                    }
                )

                //Salvando Arquivo PONTOS válidos ...
                arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_PONTOS_'
                arqsE += extensao_csv[0]
                arqsE += '.csv'

                let arqCSV = objSimda[y].get_str_CSV_pontos_validos()

                fs.writeFile
                (   arqsE ,  arqCSV ,
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo de PONTOS VÁLIDOS ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo de PONTOS VÁLIDOS ${arqsE}.`)

                    }
                )

                //Salvando Arquivo RELATORIO ...
                let num_total = objSimda[y].get_num_pares()
                let contLatLong = objSimda[y].get_contLatLong()
                let contLongLat = objSimda[y].get_contLongLat()
                let contDefeito = objSimda[y].get_contDefeito()
                let num_perc = objSimda[y].get_numPerc()
                let str_perc = objSimda[y].get_str_perc()
                let contOut = objSimda[y].get_contOut()
                let num_percOut = ( num_total > 0 ) ? 100*contOut/num_total : 0
                let str_percOut = num_percOut.toFixed(2)
                let relatorio = (`De um total de ${num_total} pares de coordenadas, foram contabilizados:\n- ${contLatLong} pares de coordenadas com posições normais ( Lat , Long );\n- ${contLongLat} pares de coordenadas com posições invertidas ( Long , Lat );\n- ${contDefeito} pares contendo strings das coordenadas defeituosas (inválidas) ( ${str_perc}% );\n- ${contOut} coordenadas válidas, mas fora (outlier) da Cidade de Fortaleza ( ${str_percOut}% );\n- Total de ${contOut+contDefeito} pares de coordenadas rejeitadas (${(num_percOut+num_perc).toFixed(2)}% do total).`)

                arqsE = __dirname + '/out/'
                arqsE += arqsTrechos[0]
                arqsE += '_RELATORIO_'
                arqsE += arqsTrechos[1]

                fs.writeFile
                (   arqsE ,  relatorio , 
                    err =>
                    {
                        ( err ) ? console.log(`erro na escrita do Arquivo RELATÓRIO ${arqsE} 777`) : 
                                    console.log(`sucesso na escrita do Arquivo RELATÓRIO ${arqsE}.`)
                    }
                )
            }
        }       )

/*
// Método Auxiliar utilizado junto com o require comentado no início para obter as coordenadas da fronteira retangular da cidade de Fortaleza
console.log( "Coordenadas Limites:" )
maxLat = -90
minLat = 90
maxLong = -90
minLong = 90
let limLat = lim.features[0].geometry.coordinates
let limCoord = [].concat( ...limLat )
//console.log( 'Coordenadas são:', limCoord )
for ( let i=0; i< limCoord.length ; i++ )
{
    maxLat = ( limCoord[i][1] > maxLat) ? limCoord[i][1] : maxLat
    minLat = ( limCoord[i][1] < minLat) ? limCoord[i][1] : minLat
    maxLong = ( limCoord[i][0] > maxLong) ? limCoord[i][0] : maxLong
    minLong = ( limCoord[i][0] < minLong) ? limCoord[i][0] : minLong
}

const tam = lim.features.length

for( let l = 1; l < tam; l++ )
{
    limLat = lim.features[l].geometry.coordinates
    limCoord = [].concat( ...limLat )
    
    for ( let i=0; i< limCoord.length ; i++ )
    {
        maxLat = ( limCoord[i][1] > maxLat) ? limCoord[i][1] : maxLat
        minLat = ( limCoord[i][1] < minLat) ? limCoord[i][1] : minLat
        maxLong = ( limCoord[i][0] > maxLong) ? limCoord[i][0] : maxLong
        minLong = ( limCoord[i][0] < minLong) ? limCoord[i][0] : minLong
    }
    
}


console.log( 'Latitude Máxima perto do Equador é ' , maxLat )
console.log( 'Latitude Mínima é ' , minLat )

console.log( 'Longitude Máxima perto do Equador é ' , maxLong )
console.log( 'Longitude Mínima é ' , minLong )
*/

