um aplicativo auxiliar de coleta de dados para o back-end do Webdengue.

	Autor: Leonardo Neves de Araujo - https://github.com/leoludao - leoludao@gmail.com.
	Primeira Versão: 22/03/2023


