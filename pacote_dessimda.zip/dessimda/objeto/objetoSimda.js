fs = require('fs')

function ObjetoSimda( string_arquivo )
{
    const sf13Cab = '{"type":"FeatureCollection",'     
    const dados = string_arquivo

    // Fronteira Retangular da cidade de Fortaleza
    const maxLat = -3.691721589926859    // Fronteira horizontal mais ao Norte da cidade de Fortaleza
    const minLat = -3.894505402919732    // Fronteira horizontal mais ao Sul da cidade de Fortaleza
    const maxLong = -38.40177024109318   // Fronteira vertical mais ao Leste (Direita) da cidade de Fortaleza
    const minLong = -38.6379317058251    // Fronteira vertical mais ao Oeste (Esquerda) da cidade de Fortaleza

    get_sem_IN = () =>
    {
        cab = dados.split(sf13Cab)
        sf13 = sf13Cab + cab[1]
        let anosem = cab[0].split('&sem_pri=')[1].split('&')[0]
        let sem = parseInt(anosem.substring(4,6))
        return ( sem >= 10 ) ? '_s0' + sem : '_s00' + sem
    }
    const sem = get_sem_IN()

    get_ano_IN = () =>
    {
        cab = dados.split(sf13Cab)
        sf13 = sf13Cab + cab[1]
        let anosem = cab[0].split('&sem_pri=')[1].split('&')[0]
        return ( 'a' + anosem.substring(0,4) )
    }
    const ano = get_ano_IN()

    get_yek_IN = () =>
    {
        cab = dados.split(sf13Cab)
        sf13 = sf13Cab + cab[1]
        return parseInt(cab[0].split('key=')[1].split('&')[0])
    }
    const yek = get_yek_IN()

    let sf13_str_orig_IN = (data) =>
    {
        cab = data.split(sf13Cab)
        sf13 = sf13Cab + cab[1]
        return sf13
    }

    const sf13_str_orig = sf13_str_orig_IN(dados)
    const sf13_obj_orig = JSON.parse( sf13_str_orig )

    const reche = sf13_obj_orig.features.length == 0 ? 'vazio' : Object.keys(sf13_obj_orig.features[0].geometry)[2]

    let lats_cripts_orig = []
    let longs_cripts_orig = []

    if( reche != 'vazio' )
    {
        sf13_obj_orig.features.forEach
        (
            f =>
            {
                lats_cripts_orig.push(f.geometry[`${reche}`][0])
                longs_cripts_orig.push(f.geometry[`${reche}`][1])
            }
        )
    }
    const posLong = yek   // Por default o SIMDA monta os JSONS.coordinates com pares ( Long , Lat ) => ( LTM4 , LTMu ),
                            // Mas o Webdengue precisa dos pares cpmo ( Lat , Long )
    const posLat = posLong + 1;

    let regra1 = "^[0-z]{"
    regra1 += posLat
    regra1 += "}LTM(.*)"
    const rgLat = new RegExp(regra1);

    let regra2 = "^[0-z]{"
    regra2 += posLong
    regra2 += "}LTM(.*)"
    const rgLong = new RegExp(regra2);

    let lats_cripts_podados = []
    let longs_cripts_podados = []
    
    let contLatLong_IN = 0
    let contLongLat_IN = 0
    let contDefeito_IN = 0
    for( let i = 0; i < lats_cripts_orig.length; i++)
    {
        let aux = ''
        if( lats_cripts_orig[i].match(rgLat) )
        {
            contLatLong_IN++
            lats_cripts_podados.push( lats_cripts_orig[i].substring(posLat).substring(0,12) )
            longs_cripts_podados.push( longs_cripts_orig[i].substring(posLong).substring(0,12) )
            // Não precisa troca de posição das coord criptografadas
        }
        else if( lats_cripts_orig[i].match(rgLong) )
        {
            contLongLat_IN++
            lats_cripts_podados.push( longs_cripts_orig[i].substring(posLat).substring(0,12) )
            longs_cripts_podados.push( lats_cripts_orig[i].substring(posLong).substring(0,12) )

            // Precisa troca de posição das coord criptografadas. Então ...
            aux += lats_cripts_orig[i]
            lats_cripts_orig[i] = longs_cripts_orig[i]
            longs_cripts_orig[i] = aux
        }
        else
        {
            contDefeito_IN++
            lats_cripts_podados.push('-.0')
            longs_cripts_podados.push('-.0')
        }
    }

    const contLongLat = contLongLat_IN
    const contLatLong = contLatLong_IN
    const contDefeito = contDefeito_IN


    //  Devolvendo as coordenadas criptografadas (eventualmente trocadas de posição),
    //  para o Sexta-Feir... ops: pro Json original, ou quaseOriginal !!
    let sf13_obj_orig_trocado_IN = sf13_obj_orig
    for( let i = 0; i < lats_cripts_orig.length; i++)
    {
        sf13_obj_orig_trocado_IN.features[i].geometry[`${reche}`][0] = lats_cripts_orig[i]
        sf13_obj_orig_trocado_IN.features[i].geometry[`${reche}`][1] = longs_cripts_orig[i]
    }

    const sf13_obj_orig_trocado = sf13_obj_orig_trocado_IN

    const latLong_cripts_concat = lats_cripts_podados.concat(longs_cripts_podados)    

    const numPares = lats_cripts_orig.length
    const numPerc = ( numPares > 0 ) ? 100*contDefeito/numPares : 0
    const strPerc = numPerc.toFixed(2)

    // SETTERS do Objeto

    let sf13_obj_descript
    this.set_sf13_obj_descript = ( novo_sf13 ) =>
    {
        sf13_obj_descript = novo_sf13
    }

    this.set_latLong_descript = (vetorSaidaLat , vetorSaidaLong ) =>
    {
        let sf13_obj_descript_IN = sf13_obj_orig_trocado
        for( let i = 0; i < numPares; i++)
        {            
            sf13_obj_descript_IN.features[i].geometry.coordinates[0] = vetorSaidaLat[i]
            sf13_obj_descript_IN.features[i].geometry.coordinates[1] = vetorSaidaLong[i]
        }
        this.set_sf13_obj_descript(sf13_obj_descript_IN)
    }

    // FUNÇÕES ESPECIAIS do Objeto
    
    this.get_lista_de_pares_de_coordenadas_descript = () =>
    {
        for( let i = 0; i < numPares; i++)
        {
            f = this.get_obj_JSON_descript_sem_podas().features[i]
            console.log( `(${f.geometry.coordinates[0]}) , (${f.geometry.coordinates[1]})` )
        }
    }

    // Função para efetuar Podas de JSON com coordenadas inválidas ...
    // E criando como subprodutos objs JSON podado e outliers, e arquivos CSV de pontos válidos e de outliers

    let sf13_obj_podado

    let sf13_obj_outliers

    let outliersFeat
    
    let contOut = 0
    let arqCSV = 'LAT,LONG,PONTOS\n'
    let arqCSVOut = 'LAT,LONG,OUTLIERS\n'
    
    this.efetuar_podas = () =>
    {
        let sf13Aux_IN = this.get_obj_JSON_descript_sem_podas()
        let sf13Podado_IN = JSON.parse( this.get_str_JSON_descript_sem_podas() )
        sf13_obj_outliers = JSON.parse( this.get_str_JSON_descript_sem_podas() )

        sf13Podado_IN.features = []
        let new_outliersFeat = []
        sf13_obj_outliers.features = []

        for( let i = 0; i < sf13Aux_IN.features.length ; i++ )
        {
            let auxstr = sf13Aux_IN.features[i].geometry.coordinates[0] + ""
            if  (   ( auxstr != '-.0'  ) &&
                    ( sf13Aux_IN.features[i].geometry.coordinates[0] >= minLat) &&
                    ( sf13Aux_IN.features[i].geometry.coordinates[0] <= maxLat) &&
                    ( sf13Aux_IN.features[i].geometry.coordinates[1] >= minLong) &&
                    ( sf13Aux_IN.features[i].geometry.coordinates[1] <= maxLong)
                )
            {
                arqCSV += sf13Aux_IN.features[i].geometry.coordinates[0]
                arqCSV += ','
                arqCSV += sf13Aux_IN.features[i].geometry.coordinates[1]
                arqCSV += '\n'
                sf13Podado_IN.features.push(sf13Aux_IN.features[i])
            }
            else
            {
                if ( auxstr == '-.0' )
                {
                    new_outliersFeat.push(sf13Aux_IN.features[i])   // <-- outliersFeat guarda os outliers
                }
                else
                {
                    new_outliersFeat.push(sf13Aux_IN.features[i])   // <-- outliersFeat guarda os outliers
                    contOut++
                }
            }
        }
        sf13_obj_podado = sf13Podado_IN

        sf13_obj_outliers.features = sf13_obj_outliers.features.concat(new_outliersFeat)
        for ( let u = 0; u < sf13_obj_outliers.features.length; u++ )
        {
            let auxstr = sf13_obj_outliers.features[u].geometry.coordinates[0] + ""
            if  ( auxstr != '-.0'  )
            {
                arqCSVOut += sf13_obj_outliers.features[u].geometry.coordinates[0]
                arqCSVOut += ','
                arqCSVOut += sf13_obj_outliers.features[u].geometry.coordinates[1]
                arqCSVOut += ','
                arqCSVOut += ano
                arqCSVOut += sem
                arqCSVOut += '\n'    
            }
        }
    }

    // GETTERS do Objeto:


    this.get_obj_JSON_descript_sem_podas = () =>
    {
        return sf13_obj_descript
    }

    this.get_str_JSON_descript_sem_podas = () =>
    {
        return JSON.stringify(sf13_obj_descript)
    }

    this.get_obj_JSON_descript_podado = () =>
    {
        return sf13_obj_podado
    }

    this.get_obj_JSON_descript_outliers = () =>
    {
        return sf13_obj_outliers
    }

    this.get_outliersFeat = () =>
    {
        return outliersFeat
    }

    this.get_str_CSV_pontos_validos = () =>
    {
        return arqCSV
    }

    this.get_str_CSV_pontos_outliers = () =>
    {
        return arqCSVOut
    }

    this.get_contLongLat = () =>
    {
        return contLongLat
    }

    this.get_contLatLong = () =>
    {
        return contLatLong
    }

    this.get_contDefeito = () =>
    {
        return contDefeito
    }

    this.get_contOut = () =>
    {
        return contOut
    }

    this.get_numPerc = () =>
    {
        return numPerc
    }

    this.get_str_perc = () =>
    {
        return strPerc
    }

    this.get_latLong_cript_concat = () =>
    {
        return latLong_cripts_concat
    }

    this.get_num_pares = () =>
    {
        return numPares
    }
 


    //console.log(this.get_reche())
    //console.log(lats_cripts_orig)
    //console.log(posLat)
    //console.log(yek)
    //console.log(this.get_num_pares() * 2)
}




module.exports = { ObjetoSimda }
    
