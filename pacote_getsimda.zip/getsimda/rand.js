function gerar_randomico( min, max , vezes )
{
    if (vezes < 1)
    {
        return 0
    }
    else if(vezes == 1)
    {
        return Math.floor( min + Math.random() * (max - min + 1) )
    }
    else
    {
        for(let i = 1 ; i <= vezes; i++)
        {
            let raux = []
            raux.push(Math.floor( min + Math.random() * (max - min + 1) ))
            //  console.log( raux )
            return raux
        }
    }
}

module.exports = { gerar_randomico }

//gerar_randomico( 3 , 9 , 50 )