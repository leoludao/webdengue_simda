Um coletador automático de arquivos de notificação jsons diretamente do site do SIMDA.

	Autor: Leonardo Neves de Araujo - https://github.com/leoludao - leoludao@gmail.com.
	Primeira Versão: 25/09/2023


