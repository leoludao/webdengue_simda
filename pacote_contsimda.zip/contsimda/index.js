fs = require('fs')
descript = require('./Relatorio/objetoRelatorio')

const arqsL = __dirname + '/in'

var nomesArqs = fs.readdirSync( arqsL );

// Lando e carregando no Array 'conteúdo' Todos os conteúdos dos Arquivos da pasta de entrada 'in'
let conteudo = []
nomesArqs.forEach
( e =>
    {
        console.log(`\n\nLendo Arquivo ${e} ...`)
        conteudo.push ( fs.readFileSync( `${arqsL}/${e}`, 'utf-8') )
    }
)

const ano_atual = nomesArqs[0].split('ANO_')[1].split('_SEMANA')[0]


// Criando Todos os Objetos Simda, um para cada Arquivo da pasta de entrada 'in'
let objSimda = []
for( let y = 0 ; y < conteudo.length; y++ )
{
        let e = nomesArqs[y]
        objSimda.push( new descript.ObjetoRelatorio( e , conteudo[y] ) )
}

let arqCasos = ''
let w = 0
let sem_atual = 0
for( let x = 0 ; x < objSimda.length; x++ )
{
    sem_atual = x + 1
    w = objSimda[x].get_semana()
    if ( w == sem_atual )
    {
        arqCasos += (sem_atual < 10) ? 'S_00' : 'S_0'
        arqCasos += sem_atual
        arqCasos += '\t'
        arqCasos += objSimda[x].get_num_casos()
        if ( objSimda[x].get_num_casos_out() != 0 )
        {
            arqCasos += '\t'
            arqCasos += 'OUT = '
            arqCasos += objSimda[x].get_num_casos_out()
        }
        arqCasos += '\n'
    }
    else
    {
        for( let y = 0 ; y < objSimda.length; y++ )
        {
            let e = objSimda[y]
            if ( e.get_semana() == sem_atual )
            {
                arqCasos += (sem_atual < 10) ? 'S_00' : 'S_0'
                arqCasos += sem_atual
                arqCasos += '\t'
                arqCasos += e.get_num_casos()
                if ( e.get_num_casos_out() != 0 )
                {
                    arqCasos += '\t'
                    arqCasos += 'OUT = '
                    arqCasos += e.get_num_casos_out()
                }
                arqCasos += '\n'
            }
        }
    }
}

//Salvando Arquivo CASOS SEMANAIS DE DENGUE ...
let arqsE = __dirname + '/out/'
arqsE += 'Casos_Simda_'
arqsE += ano_atual
arqsE += '.txt'

fs.writeFile
(   arqsE ,  arqCasos , 
    err =>
    {
        ( err ) ? console.log(`erro na escrita do Arquivo CASOS SEMANAIS DE DENGUE ${arqsE} 777`) : 
                    console.log(`sucesso na escrita do Arquivo CASOS SEMANAIS DE DENGUE ${arqsE}.`)

    }
)