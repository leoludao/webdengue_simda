fs = require('fs')

function ObjetoRelatorio( nome_arquivo , string_arquivo )
{
    const dados = string_arquivo
    const nome = nome_arquivo

    get_ordem_IN = () =>
    {
        const trechos = nome.split('_RELAT')
        const ladoTrechoEsq = trechos[0]
        const str = ladoTrechoEsq.split('SEMANA_0')[1]
        const num_sem = parseInt(str)
        //console.log('Numero da semana = ' + num_sem )
        return num_sem
    }
    const num_semana = get_ordem_IN()


    get_pares_IN = () =>
    {
        const linhas = dados.split('\n')
        const linhaNorm = linhas[1]
        const linhaInv = linhas[2]
        const str_norm = linhaNorm.split(' pares')[0].split('- ')[1]
        const str_inv = linhaInv.split(' pares')[0].split('- ')[1]

        const num_norm = parseInt(str_norm)
        //console.log('Numero Norm  = ' + num_norm )

        const num_inv = parseInt(str_inv)
        //console.log('Numero Inv  = ' + num_inv )

        return (num_norm == 0 ) ? num_inv : num_norm        

    }
    const num_casos = get_pares_IN()

    get_out_IN = () =>
    {
        const linhas = dados.split('\n')
        const linhaOut = linhas[4]

        const str_out = linhaOut.split(' coordenadas')[0].split('- ')[1]

        const num_out = parseInt(str_out)

        return num_out
    }
    const num_casos_out = get_out_IN()



    this.get_semana = () =>
    {
        return num_semana
    }

    this.get_num_casos = () =>
    {
        return num_casos
    }

    this.get_num_casos_out = () =>
    {
        return num_casos_out
    }


}




module.exports = { ObjetoRelatorio }
    
