Um contador de casos e pontos outliers, que, a partir dos relatórios semanais do dessimda, gera um relatório anual e mais geral, indicando precisamente quais as semanas que tiveram problemas de outliers.

	Autor: Leonardo Neves de Araujo - https://github.com/leoludao - leoludao@gmail.com.
	Primeira Versão: 22/03/2023


